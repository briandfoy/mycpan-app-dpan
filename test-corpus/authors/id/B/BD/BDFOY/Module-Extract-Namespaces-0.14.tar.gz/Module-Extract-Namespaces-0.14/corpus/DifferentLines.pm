#!/usr/local/bin/perl

use strict;
use warnings;

package # hide this from PAUSE
	Foo::Comment;
	
package
	Foo::Newline;