#This module shouldn't have any package declarations

use strict;
use warnings;

print "Hello World!";

1;