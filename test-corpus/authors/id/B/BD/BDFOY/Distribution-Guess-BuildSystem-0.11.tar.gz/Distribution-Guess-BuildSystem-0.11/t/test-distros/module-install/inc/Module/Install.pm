package Module::Install;

our $VERSION = '999.879';

1;