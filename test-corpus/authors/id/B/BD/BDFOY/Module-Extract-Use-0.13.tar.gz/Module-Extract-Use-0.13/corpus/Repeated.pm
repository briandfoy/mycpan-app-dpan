package Local::Repeated;

use strict;
use warnings;

no warnings;

use warnings;
use strict;

use constant;

package Foo;
use warnings;

{
no strict;
}

use warnings;


1;