# $Id: test_data.pl 786 2003-01-03 20:17:26Z comdog $

package iTunesTest;

$Test_playlist = 'Mac-iTunes test';
$Test_mp3      = 'mp3/The_Wee_Kirkcudbright_Centipede.mp3';
$Title         = 'The Wee Kirkcudbright Centipede';
$Genre         = '';
$Artist        = 'The Tappan Sisters';
$Time          = 20.245;

$Track_name    = 'The Wee Kirkcudbright Centipede';
